import React from 'react';
import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBCol } from 'mdbreact';

class Skillcard extends React.Component{
    render(){
        return (
            <MDBCol style={{marginTop:"10px"}}>
              <MDBCard style={{ width: "22rem" }}>                
                <MDBCardBody>                
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
          )
    }
}


    export default Skillcard;