import React from 'react';
import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBCol } from 'mdbreact';

class Profilecard extends React.Component{
    render(){
        return (
            <MDBCol>
              <MDBCard style={{ width: "22rem" }}>
                <MDBCardImage className="img-fluid" src="http://simpleicon.com/wp-content/uploads/user1.png" waves />
                <MDBCardBody>
                  <MDBCardTitle>Ravinga Sewwandi Perera</MDBCardTitle>
                  <MDBCardText>
                    I am capable of gas negima. Energic soul.
                    <input style={{marginTop:"10px"}}placeholder="First Name"></input>
                    <input style={{marginTop:"10px"}}placeholder="First Name"></input>
                    <input style={{marginTop:"10px"}}placeholder="First Name"></input>
                    <input style={{marginTop:"10px"}}placeholder="First Name"></input>
                  </MDBCardText>
                  <MDBBtn href="#">Edit Profile</MDBBtn>
                  <MDBBtn href="#" disabled>Done </MDBBtn>
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
          )
    }
}
export default Profilecard;