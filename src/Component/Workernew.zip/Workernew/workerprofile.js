import React from "react";
import { MDBContainer, MDBRow, MDBCol } from "mdbreact";
import Profilecard from "./profilecard";
import Linechart from "./Linechart";
import AddSkill from "./Addskill";
import Skillcard from "./Skillcard";
import Summary from "./Summary";

class Workerprofile extends React.Component{
    render(){
        return (
            <MDBContainer>
              <MDBRow>
                <MDBCol md="4"><Profilecard /></MDBCol>
                <MDBCol md="4">
                      <AddSkill/>
                      <Skillcard/>
                      <Skillcard/>
                </MDBCol>
                <MDBCol md="4">< Linechart /></MDBCol>
              </MDBRow>
        
              <MDBRow>
                <MDBCol md="3"><Summary/></MDBCol>
                <MDBCol md="3"></MDBCol>
                <MDBCol md="3"></MDBCol>
                <MDBCol md="3"></MDBCol>
              </MDBRow>
            </MDBContainer>
          );
    }
}

export default Workerprofile;