import React from 'react';

import { MDBContainer, MDBRow,  MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBCol } from 'mdbreact';

export default class AddSkill extends React.Component{
    render(){
        return(
    <MDBCol>
      <MDBCard style={{ width: "22rem" }}>
        
        <MDBCardBody>
        <MDBContainer>
            <MDBRow>
              <MDBCol md="11">
                <form>
                  <h5 style={{textAlign:"center"}}>Add a Skill</h5>                  
                  <input
                    type="email"                  
                    className="form-control"
                    placeholder="skill title"
                  />
                  <br />                 
                  <input
                    type="password"             
                    className="form-control"
                    placeholder="Skill Description"
                  />
                  <br />
                  <input
                    type="password"     
                    className="form-control"
                    placeholder="Hourly Rate"
                  />
                  <div className="text-center mt-4">
                    <MDBBtn color="indigo" type="submit">Login</MDBBtn>
                  </div>
                </form>
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </MDBCardBody>
      </MDBCard>
    </MDBCol>


            
        );
    }
}