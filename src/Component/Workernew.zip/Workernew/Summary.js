import React from "react";
import { MDBContainer, MDBCol, MDBCard, MDBIcon, MDBBtn } from "mdbreact";

const Summary = () => {
  return (
  

    <MDBContainer className="d-flex flex-wrap">
      
      <MDBCol md="3" className="md-0 mb-4">
        <MDBCard className="card-image" style={{
                backgroundImage:
                  "url(https://mdbootstrap.com/img/Photos/Horizontal/Nature/6-col/img%20%2873%29.jpg)"
              }}>
          <div className="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4 rounded">
            <div>
              <h6 className="pink-text">
                <MDBIcon icon="chart-pie" />
                <strong> Marketing</strong>
              </h6>
              <h3 className="py-3 font-weight-bold">
                <strong>This is card title</strong>
              </h3>
             
              <MDBBtn color="pink" rounded size="md">
                <MDBIcon far icon="clone" className="left" /> MDBView project
              </MDBBtn>
            </div>
          </div>
        </MDBCard>
      </MDBCol>
      
    </MDBContainer>

  );
}

export default Summary;